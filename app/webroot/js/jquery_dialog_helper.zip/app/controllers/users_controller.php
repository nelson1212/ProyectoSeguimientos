<?php
class UsersController extends AppController {

	var $name = 'Users';
	var $uses = array();
	var $helpers=array('Jdialog');
		 
	function index() {
		
	}	
}
?>